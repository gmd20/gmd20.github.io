// go:generate protoc -I ./ --go_out=plugins=grpc:. ./frp_manager.proto

package main

import (
	"crypto/tls"
	"crypto/x509"
	"flag"
	"io"
	"io/ioutil"
	"log"
	"math"
	"net"
	"os"
	"path"
	"path/filepath"
	"strings"
	"sync"
	"time"

	pb "frp_manager"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials"
	"google.golang.org/grpc/keepalive"

	"github.com/fsnotify/fsnotify"
)

var FRP_MANAGER_CONFIG_DIR string = "/etc/ftp_manager"

type ConfigServer struct {
	lock    sync.Mutex
	clients map[string]pb.Config_GetConfigServer
}

// caller must held server lock
func (s *ConfigServer) sendFrpConfig(srv pb.Config_GetConfigServer, clientId string) error {
	resp := pb.ConfigResponse{}
	config, err := ioutil.ReadFile(path.Join(FRP_MANAGER_CONFIG_DIR, clientId))
	if err != nil {
		resp.FrpConfig = ""
	} else {
		resp.FrpConfig = string(config)
	}

	if err := srv.Send(&resp); err != nil {
		log.Printf("send error %+v", err)
		return err
	}
	return nil
}

func (s *ConfigServer) GetConfig(srv pb.Config_GetConfigServer) error {
	var clientId string
	ctx := srv.Context()

	for {
		select {
		case <-ctx.Done():
			log.Printf("client stream down %+v", ctx.Err())
			goto connection_close
		default:
		}

		req, err := srv.Recv()
		if err == io.EOF {
			log.Println("client stream EOF")
			goto connection_close
		}
		if err != nil {
			log.Printf("receive error %+v", err)
			continue
		}

		log.Printf("device connected { %+v }", req)
		clientId = strings.ReplaceAll(req.MacAddress, ":", "")

		s.lock.Lock()
		s.clients[clientId] = srv
		err = s.sendFrpConfig(srv, clientId)
		s.lock.Unlock()
		if err != nil {
			goto connection_close
		}
	}

connection_close:
	log.Printf("device disconnected { %+v }", clientId)
	if len(clientId) > 0 {
		s.lock.Lock()
		delete(s.clients, clientId)
		s.lock.Unlock()
	}
	return nil
}

func newConfigServer() *ConfigServer {
	s := &ConfigServer{
		clients: make(map[string]pb.Config_GetConfigServer),
	}
	return s
}

func frpConfigWatch(s *ConfigServer) {
	watcher, err := fsnotify.NewWatcher()
	if err != nil {
		log.Fatal(err)
	}
	err = watcher.Add(FRP_MANAGER_CONFIG_DIR)
	if err != nil {
		log.Fatal(err)
	}
	defer watcher.Close()

	done := make(chan bool)
	for {
		select {
		case event, ok := <-watcher.Events:
			var clientId string
			if !ok {
				log.Println("file watcher thread exit")
				return
			}
			log.Println("event:", event)
			clientId = filepath.Base(event.Name)
			if (event.Op & fsnotify.Write) == fsnotify.Write {
				log.Printf("device %+v is updated", clientId)
			} else if (event.Op & fsnotify.Remove) == fsnotify.Remove {
				log.Printf("device %+v is delete", clientId)
			}
			if len(clientId) > 0 {
				s.lock.Lock()
				srv, found := s.clients[clientId]
				if found {
					s.sendFrpConfig(srv, clientId)
				} else {
					log.Printf("device %+v is offline", clientId)
				}
				s.lock.Unlock()
			}
		case err, ok := <-watcher.Errors:
			if !ok {
				log.Println("file watcher thread exit")
				return
			}
			log.Println("file watcher error:", err)
		}
	}

	<-done
}

func main() {
	var serverAddress string
	var logFilename string
	var workingDir string

	flag.StringVar(&serverAddress, "bind_addr", ":9001", "Specify the grpc server bind address, for example 0.0.0.0:9001")
	flag.StringVar(&logFilename, "log_file", "/var/log/frp_manager.log", "log filename")
	flag.StringVar(&workingDir, "working_dir", "", "working directory")
	flag.StringVar(&FRP_MANAGER_CONFIG_DIR, "frp_config_dir", "/etc/frp_manager", "the frp configure directory")
	flag.Parse()

	if len(logFilename) > 0 {
		f, err := os.OpenFile(logFilename, os.O_RDWR|os.O_CREATE|os.O_APPEND, 0666)
		if err != nil {
			log.Fatalf("error opening file: %+v", err)
		}
		defer f.Close()
		log.SetOutput(f)
	}
	log.SetFlags(log.Ldate | log.Ltime | log.Lmicroseconds | log.Lshortfile)

	if len(workingDir) > 0 {
		err := os.Chdir(workingDir)
		if err != nil {
			log.Fatalf("failed to change the working directory to %+v : %+v", workingDir, err)
		}
	}

	// grpc
	cert, err := tls.LoadX509KeyPair("server.pem", "server.key")
	if err != nil {
		log.Fatalf("failed load server.pem: %+v", err)
	}

	certPool := x509.NewCertPool()
	rootBuf, err := ioutil.ReadFile("root_ca.pem")
	if err != nil {
		log.Fatalf("failed load root_ca.pem: %+v", err)
	}
	if !certPool.AppendCertsFromPEM(rootBuf) {
		panic("Fail to append root ca")
	}

	tlsConf := &tls.Config{
		// ServerName: "frp-manager-client", // serverName需要与服务器证书内的Common Name一致
		// CipherSuites:             []uint16{tls.TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384},
		// PreferServerCipherSuites: true,
		MinVersion:   tls.VersionTLS13,
		ClientAuth:   tls.RequireAndVerifyClientCert, // 双向认证
		Certificates: []tls.Certificate{cert},
		ClientCAs:    certPool,
	}

	listener, err := net.Listen("tcp", serverAddress)
	if err != nil {
		log.Fatalf("main: failed to listen: %+v", err)
	}
	defer listener.Close()

	s := grpc.NewServer(grpc.Creds(credentials.NewTLS(tlsConf)),
		grpc.KeepaliveEnforcementPolicy(keepalive.EnforcementPolicy{
			MinTime:             10 * time.Second,
			PermitWithoutStream: true,
		}),
		grpc.KeepaliveParams(keepalive.ServerParameters{
			MaxConnectionIdle:     time.Duration(math.MaxInt64),
			MaxConnectionAge:      time.Duration(math.MaxInt64),
			MaxConnectionAgeGrace: time.Duration(math.MaxInt64),
			Time:                  20 * time.Second,
			Timeout:               20 * time.Second,
		}),
		grpc.MaxConcurrentStreams(10000),
	)
	cs := newConfigServer()

	go frpConfigWatch(cs)

	pb.RegisterConfigServer(s, cs)
	if err := s.Serve(listener); err != nil {
		log.Fatalf("main: failed to serve: %+v", err)
	}
}
