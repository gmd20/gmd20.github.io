
1. 生成根证书的私钥
```text
选的椭圆曲线算法，后面生成server和client端的时候类似
$ openssl ecparam -genkey -name prime256v1 -out root_ca.key

也可以选RSA的吧，向下面这样
$ openssl genrsa -out ca.key 2048
```


2. 生成根证书x509格式（公钥）
```text
$ openssl req -new -x509 -days 40000 -key root_ca.key -out root_ca.pem
You are about to be asked to enter information that will be incorporated
into your certificate request.
What you are about to enter is what is called a Distinguished Name or a DN.
There are quite a few fields but you can leave some blank
For some fields there will be a default value,
If you enter '.', the field will be left blank.
-----
Country Name (2 letter code) [AU]:CN
State or Province Name (full name) [Some-State]:GuangDong
Locality Name (eg, city) []:GuangZhou
Organization Name (eg, company) [Internet Widgits Pty Ltd]:TEST
Organizational Unit Name (eg, section) []:GZ
Common Name (e.g. server FQDN or YOUR name) []:TEST.com
Email Address []:dev@TEST.com


检查根证书有效期
openssl x509 -text -noout -in root_ca.pem
```

3. 生成server端的私钥
```text
$ openssl ecparam -genkey -name prime256v1 -out server.key
```

4. 生成server端的证书请求（提供的根证书机构进行签发）
```text
$ openssl req -new -key server.key -out server.csr
You are about to be asked to enter information that will be incorporated
into your certificate request.
What you are about to enter is what is called a Distinguished Name or a DN.
There are quite a few fields but you can leave some blank
For some fields there will be a default value,
If you enter '.', the field will be left blank.
-----
Country Name (2 letter code) [AU]:CN
State or Province Name (full name) [Some-State]:GuangDong
Locality Name (eg, city) []:GuangZhou
Organization Name (eg, company) [Internet Widgits Pty Ltd]:TEST
Organizational Unit Name (eg, section) []:GZ
Common Name (e.g. server FQDN or YOUR name) []:frp-manager-server
Email Address []:dev@TEST.com

Please enter the following 'extra' attributes
to be sent with your certificate request
A challenge password []:
An optional company name []:

其中“Common Name”必须和后面golang代码里面的tls.Config{ ServerName的配置一致，
tls连接时会校验这个Common Name属性的内容。

不过按照官方说法Common Name已经在2000年就被废弃了，证书里面最好使用Subject
Alternative Name (SAN)，SAN这个好像可以配置域名通配符和同时配置多个不通过的
域名吧

这个SAN需要使用配置文件的方式吧
openssl req -new -sha256 \
    -key server.key \
    -subj "/C=CN/ST=GuangDong/O=TEXT, Inc./CN=example.com" \
    -reqexts SAN \
    -config <(cat /etc/ssl/openssl.cnf \
        <(printf "\n[SAN]\nsubjectAltName=DNS:example.com,DNS:www.example.com")) \
    -out server.csr
```


5. 用根证书给server端签名颁发证书
```text
$ openssl x509 -req -sha256 -CA root_ca.pem -CAkey root_ca.key -CAcreateserial -days 35000 -in server.csr -out server.pem
Signature ok
subject=C = CN, ST = GuangDong, L = GuangZhou, O = TEST, OU = GZ, CN =
*.TEST.com, emailAddress = dev@TEST.com
Getting CA Private Key
```


6. 生成client端的密钥
```text
$ openssl ecparam -genkey -name prime256v1 -out client.key
```


7. 生成client端的证书请求
```text
$ openssl req -new -key client.key -out client.csr
You are about to be asked to enter information that will be incorporated
into your certificate request.
What you are about to enter is what is called a Distinguished Name or a DN.
There are quite a few fields but you can leave some blank
For some fields there will be a default value,
If you enter '.', the field will be left blank.
-----
Country Name (2 letter code) [AU]:CN
State or Province Name (full name) [Some-State]:GuangDong
Locality Name (eg, city) []:Guangzhou
Organization Name (eg, company) [Internet Widgits Pty Ltd]:TEST
Organizational Unit Name (eg, section) []:GZ
Common Name (e.g. server FQDN or YOUR name) []:frp-manager-client
Email Address []:dev@TEST.com

Please enter the following 'extra' attributes
to be sent with your certificate request
A challenge password []:
An optional company name []:
```

8. 自签名client端证书
```text
$ openssl x509 -req -sha256 -CA root_ca.pem -CAkey root_ca.key -CAcreateserial -days 35000 -in client.csr -out client.pem
Signature ok
subject=C = CN, ST = GuangDong, L = GuangZhou, O = TEST, OU = GZ, CN =
*.TEST.com, emailAddress = dev@amttgroup.com
Getting CA Private Key
```



9. 检查证书的有效期
```text
openssl x509 -text -noout -in root_ca.pem
openssl x509 -text -noout -in client.pem
openssl x509 -text -noout -in server.pem
openssl verify -verbose -CAfile root_ca.pem server.pem
openssl verify -verbose -CAfile root_ca.pem client.pem
```

10. 注意不同openssl版本的问题
```text
windows平台自带的新版的openssl 1.1.1c 创建的证书，centos 7.7 自带的 OpenSSL 1.0.2k-fips  26 Jan 2017
识别不出来。 好像是证书的serial nubmer长度多了一些。centos 7.7编译的golang加载也是报错的。
反过来用旧版生成的证书，新版校验就没有问题。
```
