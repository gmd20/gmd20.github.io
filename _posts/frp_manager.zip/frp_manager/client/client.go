package main

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	"flag"
	"io/ioutil"
	"log"
	"net"
	"os"
	"os/exec"
	"strings"
	"time"

	pb "frp_manager"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials"
	"google.golang.org/grpc/keepalive"
)

var frpConfig string
var frpcCmd *exec.Cmd

func startFrpc(config string) error {
	err := ioutil.WriteFile("/etc/frpc.ini", []byte(config), 0644)
	if err != nil {
		log.Println(err)
		return err
	}

	frpcCmd = exec.Command("frpc", "-c", "/etc/frpc.ini")
	err = frpcCmd.Start()
	if err != nil {
		log.Println(err)
		return err
	}
	if frpcCmd.Process != nil {
		log.Printf("frpc was started. Pid = %+v", frpcCmd.Process.Pid)
	}
	return nil
}

func stopFrpc() {
	if frpcCmd != nil && frpcCmd.Process != nil {
		log.Printf("frpc will be stopped. Pid = %+v", frpcCmd.Process.Pid)
		frpcCmd.Process.Kill()
		frpcCmd.Wait()
		frpcCmd = nil
	}
}

func isFrpcRunning() bool {
	if frpcCmd != nil && frpcCmd.Process != nil {
		if frpcCmd.ProcessState == nil || !frpcCmd.ProcessState.Exited() {
			log.Printf("frpc is running. Pid = %+v", frpcCmd.Process.Pid)
			return true
		}
	}
	return false
}

func runfrpManager(serverAddress string, macAddress string,
	deviceType string, serialNumber string, desc string) error {
	cert, err := tls.LoadX509KeyPair("client.pem", "client.key")
	if err != nil {
		log.Fatalf("failed load client.pem: %+v", err)
	}

	certPool := x509.NewCertPool()
	rootBuf, err := ioutil.ReadFile("root_ca.pem")
	if err != nil {
		log.Fatalf("failed load root_ca.pem: %+v", err)
	}
	if !certPool.AppendCertsFromPEM(rootBuf) {
		log.Fatalf("failed to append root_ca.pem: %+v", err)
	}

	creds := credentials.NewTLS(&tls.Config{
		ServerName:   "frp-manager-server", // serverName需要与服务器证书内的Common Name一致
		Certificates: []tls.Certificate{cert},
		RootCAs:      certPool,
	})

	conn, err := grpc.Dial(serverAddress, grpc.WithTransportCredentials(creds),
		grpc.WithKeepaliveParams(keepalive.ClientParameters{
			Time:                time.Duration(20) * time.Second,
			Timeout:             time.Duration(20) * time.Second,
			PermitWithoutStream: true,
		}))
	if err != nil {
		log.Printf("failed to dail %+v, error %+v", serverAddress, err)
		return err
	}
	defer conn.Close()

	client := pb.NewConfigClient(conn)
	stream, err := client.GetConfig(context.Background())
	if err != nil {
		log.Printf("open client stream error %v", err)
		return err
	}

	hostname, err := os.Hostname()
	req := pb.ConfigRequest{
		MacAddress:   macAddress,
		Hostname:     hostname,
		DeviceType:   deviceType,
		SerialNumber: serialNumber,
		Description:  desc,
	}
	if err := stream.Send(&req); err != nil {
		log.Printf("can not send %v", err)
		return err
	}

	for {
		rsp, err := stream.Recv()
		if err != nil {
			log.Printf("client stream recv err %+v", err)
			return err
		}

		if len(strings.TrimSpace(rsp.FrpConfig)) == 0 {
			stopFrpc()
			frpConfig = rsp.FrpConfig
		} else {
			if frpConfig == rsp.FrpConfig {
				if isFrpcRunning() {
					continue
				}
			} else {
				stopFrpc()
				frpConfig = rsp.FrpConfig
			}
			startFrpc(frpConfig)
		}

		ctx := stream.Context()
		select {
		case <-ctx.Done():
			log.Printf("client stream down %+v", ctx.Err())
			return ctx.Err()
		default:
		}
	}

	return nil
}

func main() {
	var serverAddress string
	var logFilename string
	var workingDir string
	var macAddress string
	var ifname string
	var deviceType string
	var serialNumber string
	var desc string

	flag.StringVar(&serverAddress, "server_addr", "192.168.1.1:9001", "Specify grpc server address, for example 192.168.1.1:9001")
	flag.StringVar(&logFilename, "log_file", "/var/log/frp_manager.log", "log filename")
	flag.StringVar(&workingDir, "working_dir", "", "working directory")
	flag.StringVar(&macAddress, "mac_address", "", "MAC address or clientId string")
	flag.StringVar(&ifname, "ifname", "eth0", "the MAC address of this network interface is used if the mac_address parameter is empty ")
	flag.StringVar(&deviceType, "device_type", "unknown", "device type")
	flag.StringVar(&serialNumber, "serial_number", "", "serial number")
	flag.StringVar(&desc, "description", "", "description")
	flag.Parse()

	if len(logFilename) > 0 {
		f, err := os.OpenFile(logFilename, os.O_RDWR|os.O_CREATE|os.O_APPEND, 0666)
		if err != nil {
			log.Fatalf("error opening file: %+v", err)
		}
		defer f.Close()
		log.SetOutput(f)
	}
	log.SetFlags(log.Ldate | log.Ltime | log.Lmicroseconds | log.Lshortfile)

	if len(workingDir) > 0 {
		err := os.Chdir(workingDir)
		if err != nil {
			log.Fatalf("failed to change the working directory to %+v : %+v", workingDir, err)
		}
	}

	if len(macAddress) == 0 {
		interfaces, _ := net.Interfaces()
		for _, interf := range interfaces {
			if interf.Name == ifname {
				macAddress = interf.HardwareAddr.String()
				break
			}
		}
	}

	if len(macAddress) == 0 {
		log.Fatalf("please specify a clientId or a MACAddress")
	}

	interval := 1
	for {
		runfrpManager(serverAddress, macAddress, deviceType, serialNumber, desc)
		time.Sleep(time.Duration(interval) * time.Second)
		if interval < 128 {
			interval *= 2
		} else {
			interval = 1
		}
	}
}
